/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package servletPack;

/**
 *
 * 
 */
public class CompilerServerPathSettings {
    public final static String compilerServerPath = "D:\\JP12\\5408.TrueDistributedVirtualCompilerEditor\\Current";
    
    
}
