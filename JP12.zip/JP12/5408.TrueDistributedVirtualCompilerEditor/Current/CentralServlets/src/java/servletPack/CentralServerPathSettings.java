/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package servletPack;

/**
 *
 * @author Administrator
 */
public class CentralServerPathSettings {
    public final static String centralServerPath = "D:\\JP12\\5408.TrueDistributedVirtualCompilerEditor\\Current";
}

